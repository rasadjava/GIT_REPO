package com.c2n.advjava.jsp;

public class UseBeanUtil {
	public String myMethod(String content) {
		String newContent = content + "JAVA";
		return newContent;
	}
}
